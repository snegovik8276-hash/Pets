package com.example.freepets;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.util.Identifier;

public class FreePets implements ModInitializer {
    public static final String MOD_ID = "freepets";
    /** Один канал для всех кнопок: [байт действия][число целей]. */
    public static final Identifier ACTION_PACKET = new Identifier(MOD_ID, "action");

    @Override
    public void onInitialize() {
        ServerPlayNetworking.registerGlobalReceiver(ACTION_PACKET,
                (server, player, handler, buf, responseSender) -> {
                    // читаем сразу, пока буфер жив
                    final int action = buf.readByte();
                    final int count = buf.readVarInt();
                    server.execute(() -> PetActions.handle(player, action, count));
                });
    }
}
