package com.example.freepets;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.passive.TameableEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.LiteralText;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.List;
import java.util.Optional;

/** Всё, что раньше делали команды, теперь вызывается кнопками (работает в хардкоре без читов). */
public final class PetActions {
    public static final int CALL = 0;   // позвать всех питомцев
    public static final int HUNT = 1;   // послать питомца на моба в прицеле
    public static final int STOP = 2;   // отменить задания
    public static final int MODE = 3;   // переключить режим: гуляют -> охота -> следуют

    private PetActions() {}

    public static void handle(ServerPlayerEntity player, int action, int count) {
        switch (action) {
            case CALL:
                PetUtil.callPets(player);
                break;
            case HUNT:
                hunt(player, Math.max(1, Math.min(64, count)));
                break;
            case STOP:
                stop(player);
                break;
            case MODE:
                cycleMode(player);
                break;
            default:
                break;
        }
    }

    private static void msg(ServerPlayerEntity player, String text) {
        player.sendMessage(new LiteralText(text), true);
    }

    private static void cycleMode(ServerPlayerEntity player) {
        List<TameableEntity> pets = PetUtil.ownedPets(player);
        if (pets.isEmpty()) {
            msg(player, "Питомцев рядом нет");
            return;
        }
        int current = ((PetFreedom) pets.get(0)).freepets$getMode();
        int next;
        if (current == PetMode.ROAM) next = PetMode.WILD;
        else if (current == PetMode.WILD) next = PetMode.FOLLOW;
        else next = PetMode.ROAM;

        for (TameableEntity pet : pets) {
            ((PetFreedom) pet).freepets$setMode(next);
        }
        msg(player, "Питомцы (" + pets.size() + "): " + PetMode.title(next));
    }

    private static void stop(ServerPlayerEntity player) {
        int stopped = 0;
        for (TameableEntity pet : PetUtil.ownedPets(player)) {
            PetFreedom f = (PetFreedom) pet;
            PetTask task = f.freepets$getTask();
            if (task != null) {
                PetUtil.deliver(pet, task, player);
                f.freepets$setTask(null);
                pet.getNavigation().stop();
                stopped++;
            }
        }
        msg(player, "Заданий отменено: " + stopped);
    }

    private static void hunt(ServerPlayerEntity player, int count) {
        LivingEntity target = lookTarget(player);
        if (target == null) {
            msg(player, "Наведи прицел на моба, на которого послать питомца");
            return;
        }
        EntityType<?> type = target.getType();
        if (type.getSpawnGroup() == SpawnGroup.MISC) {
            msg(player, "На это питомцы не охотятся");
            return;
        }

        // Задание получает ближайший свободный питомец (не сидит, без другого задания, в радиусе 64)
        TameableEntity best = null;
        double bestDist = 64.0 * 64.0;
        for (TameableEntity pet : PetUtil.ownedPets(player)) {
            if (pet.isSitting() || ((PetFreedom) pet).freepets$getTask() != null) continue;
            double d = pet.squaredDistanceTo(player);
            if (d < bestDist) {
                best = pet;
                bestDist = d;
            }
        }
        if (best == null) {
            msg(player, "Нет свободных питомцев рядом (все сидят, заняты или далеко)");
            return;
        }

        ((PetFreedom) best).freepets$setTask(new PetTask(type, count, false));
        player.sendMessage(new LiteralText("")
                .append(best.getDisplayName())
                .append(new LiteralText(" отправился убить: " + count + " × "))
                .append(type.getName()), true);
    }

    /** Моб, на которого смотрит игрок (до 40 блоков). Питомцев и самого игрока пропускает. */
    private static LivingEntity lookTarget(ServerPlayerEntity player) {
        Vec3d start = player.getCameraPosVec(1.0F);
        Vec3d look = player.getRotationVec(1.0F).multiply(40.0);
        Vec3d end = start.add(look);
        Box search = player.getBoundingBox().stretch(look).expand(1.0);

        LivingEntity best = null;
        double bestDist = Double.MAX_VALUE;
        List<Entity> candidates = player.world.getOtherEntities(player, search, e ->
                e instanceof LivingEntity && e.isAlive() && !e.isSpectator()
                        && !(e instanceof TameableEntity && ((TameableEntity) e).isTamed()));
        for (Entity e : candidates) {
            Optional<Vec3d> hit = e.getBoundingBox().expand(e.getTargetingMargin() + 0.2).raycast(start, end);
            if (hit.isPresent()) {
                double d = start.squaredDistanceTo(hit.get());
                if (d < bestDist) {
                    bestDist = d;
                    best = (LivingEntity) e;
                }
            }
        }
        return best;
    }
}
