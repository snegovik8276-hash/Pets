package com.example.freepets;

/** Подмешивается в TameableEntity (волк, кошка, попугай). */
public interface PetFreedom {
    int freepets$getMode();
    void freepets$setMode(int mode);
    PetTask freepets$getTask();
    void freepets$setTask(PetTask task);
}
