package com.example.freepets;

public final class PetMode {
    // 0 = по умолчанию: питомцы без сохранённых данных сразу гуляют сами
    public static final int ROAM = 0;
    public static final int FOLLOW = 1;
    public static final int WILD = 2;

    private PetMode() {}

    public static String title(int mode) {
        if (mode == FOLLOW) return "ходит за тобой (как в ванили)";
        if (mode == WILD) return "гуляет сам и охотится";
        return "гуляет где хочет";
    }
}
