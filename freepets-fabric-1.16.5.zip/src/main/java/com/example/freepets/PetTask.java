package com.example.freepets;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;

import java.util.ArrayList;
import java.util.List;

public class PetTask {
    public enum Phase { HUNT, RETURN }

    public final EntityType<?> type;
    public final int goal;
    /** true = охота «для себя» в режиме wild: без сбора добычи и возврата */
    public final boolean autonomous;

    public Phase phase = Phase.HUNT;
    public LivingEntity current;
    public int kills;
    public int age;
    public int searchTicks;
    public int returnTicks;
    public final List<ItemStack> haul = new ArrayList<>();

    public PetTask(EntityType<?> type, int goal, boolean autonomous) {
        this.type = type;
        this.goal = goal;
        this.autonomous = autonomous;
    }
}
