package com.example.freepets;

import net.minecraft.entity.passive.TameableEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.LiteralText;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.world.World;

import java.util.List;

public final class PetUtil {
    private PetUtil() {}

    /** Все приручённые питомцы игрока в радиусе 128 блоков (в загруженных чанках). */
    public static List<TameableEntity> ownedPets(ServerPlayerEntity player) {
        Box box = player.getBoundingBox().expand(128.0, 128.0, 128.0);
        return player.world.getEntitiesByClass(TameableEntity.class, box,
                e -> e.isTamed() && player.getUuid().equals(e.getOwnerUuid()));
    }

    /** Кнопка «ко мне»: телепортирует всех стоящих питомцев к игроку и отменяет задания. */
    public static void callPets(ServerPlayerEntity player) {
        int called = 0;
        for (TameableEntity pet : ownedPets(player)) {
            if (pet.isSitting()) continue;
            PetFreedom f = (PetFreedom) pet;
            PetTask task = f.freepets$getTask();
            if (task != null) {
                deliver(pet, task, player);
                f.freepets$setTask(null);
            }
            teleportNear(pet, player);
            called++;
        }
        player.sendMessage(new LiteralText(called > 0
                ? "Питомцы прибежали: " + called
                : "Некого звать (все сидят или питомцев нет)"), true);
    }

    public static void teleportNear(TameableEntity pet, ServerPlayerEntity player) {
        if (pet.world != player.world) return;
        pet.getNavigation().stop();
        for (int i = 0; i < 10; i++) {
            double x = player.getX() + (pet.getRandom().nextDouble() * 6.0 - 3.0);
            double z = player.getZ() + (pet.getRandom().nextDouble() * 6.0 - 3.0);
            BlockPos feet = new BlockPos(x, player.getY(), z);
            if (isFree(pet.world, feet) && isFree(pet.world, feet.up())) {
                place(pet, x, player.getY(), z);
                return;
            }
        }
        place(pet, player.getX(), player.getY(), player.getZ());
    }

    private static boolean isFree(World world, BlockPos pos) {
        return world.getBlockState(pos).getCollisionShape(world, pos).isEmpty();
    }

    private static void place(TameableEntity pet, double x, double y, double z) {
        pet.refreshPositionAndAngles(x, y, z, pet.yaw, pet.pitch);
        pet.fallDistance = 0.0F;
    }

    /** Отдаёт добычу игроку (в инвентарь, а если места нет — на землю). */
    public static void deliver(TameableEntity pet, PetTask task, ServerPlayerEntity owner) {
        int items = 0;
        for (ItemStack stack : task.haul) {
            items += stack.getCount();
            owner.inventory.insertStack(stack);
            if (!stack.isEmpty()) {
                owner.dropItem(stack, false);
            }
        }
        task.haul.clear();
        if (items > 0 || task.kills > 0) {
            owner.sendMessage(new LiteralText("")
                    .append(pet.getDisplayName())
                    .append(new LiteralText(": убито " + task.kills + ", принёс предметов: " + items)), false);
        }
    }
}
