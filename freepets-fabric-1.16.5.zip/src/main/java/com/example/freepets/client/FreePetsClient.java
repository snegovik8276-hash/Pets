package com.example.freepets.client;

import com.example.freepets.FreePets;
import com.example.freepets.PetActions;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.options.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.text.LiteralText;
import org.lwjgl.glfw.GLFW;

/** Все кнопки меняются в Настройки -> Управление -> категория «Free Pets». */
public class FreePetsClient implements ClientModInitializer {
    private static final int[] COUNTS = {1, 2, 3, 5, 10, 20};
    private static int countIndex = 1; // по умолчанию 2 цели

    private static KeyBinding callKey, huntKey, stopKey, modeKey, countKey;

    private static KeyBinding key(String name, int code) {
        return KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.freepets." + name, InputUtil.Type.KEYSYM, code, "key.categories.freepets"));
    }

    @Override
    public void onInitializeClient() {
        callKey  = key("call",  GLFW.GLFW_KEY_V); // позвать питомцев
        huntKey  = key("hunt",  GLFW.GLFW_KEY_B); // послать на моба в прицеле
        stopKey  = key("stop",  GLFW.GLFW_KEY_G); // отменить задания
        modeKey  = key("mode",  GLFW.GLFW_KEY_H); // режим: гуляют / охота / следуют
        countKey = key("count", GLFW.GLFW_KEY_J); // сколько целей убить

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null) return;
            while (callKey.wasPressed())  send(client, PetActions.CALL);
            while (huntKey.wasPressed())  send(client, PetActions.HUNT);
            while (stopKey.wasPressed())  send(client, PetActions.STOP);
            while (modeKey.wasPressed())  send(client, PetActions.MODE);
            while (countKey.wasPressed()) {
                countIndex = (countIndex + 1) % COUNTS.length;
                client.player.sendMessage(new LiteralText("Задание: убить " + COUNTS[countIndex]), true);
            }
        });
    }

    private static void send(MinecraftClient client, int action) {
        if (!ClientPlayNetworking.canSend(FreePets.ACTION_PACKET)) {
            client.player.sendMessage(new LiteralText("На сервере нет мода Free Pets"), true);
            return;
        }
        PacketByteBuf buf = PacketByteBufs.create();
        buf.writeByte(action);
        buf.writeVarInt(COUNTS[countIndex]);
        ClientPlayNetworking.send(FreePets.ACTION_PACKET, buf);
    }
}
