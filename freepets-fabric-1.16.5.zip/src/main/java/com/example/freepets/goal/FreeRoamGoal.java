package com.example.freepets.goal;

import com.example.freepets.PetFreedom;
import com.example.freepets.PetMode;
import net.minecraft.entity.ai.TargetFinder;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.passive.TameableEntity;
import net.minecraft.util.math.Vec3d;

import java.util.EnumSet;

/** Питомец просто бродит где хочет. */
public class FreeRoamGoal extends Goal {
    private final TameableEntity pet;
    private double x, y, z;

    public FreeRoamGoal(TameableEntity pet) {
        this.pet = pet;
        this.setControls(EnumSet.of(Goal.Control.MOVE));
    }

    @Override
    public boolean canStart() {
        PetFreedom f = (PetFreedom) pet;
        if (!pet.isTamed() || pet.isSitting() || pet.hasVehicle() || pet.isLeashed()) return false;
        if (f.freepets$getMode() == PetMode.FOLLOW || f.freepets$getTask() != null) return false;
        if (pet.getRandom().nextInt(40) != 0) return false;
        Vec3d target = TargetFinder.findTarget(pet, 12, 6);
        if (target == null) return false;
        x = target.x;
        y = target.y;
        z = target.z;
        return true;
    }

    @Override
    public boolean shouldContinue() {
        return !pet.getNavigation().isIdle() && !pet.isSitting();
    }

    @Override
    public void start() {
        pet.getNavigation().startMovingTo(x, y, z, 1.0);
    }

    @Override
    public void stop() {
        pet.getNavigation().stop();
    }
}
