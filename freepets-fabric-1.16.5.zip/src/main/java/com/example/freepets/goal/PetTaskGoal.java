package com.example.freepets.goal;

import com.example.freepets.PetFreedom;
import com.example.freepets.PetMode;
import com.example.freepets.PetTask;
import com.example.freepets.PetUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.TargetFinder;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.mob.AbstractSkeletonEntity;
import net.minecraft.entity.mob.SpiderEntity;
import net.minecraft.entity.mob.WitherSkeletonEntity;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.entity.mob.ZombifiedPiglinEntity;
import net.minecraft.entity.passive.ChickenEntity;
import net.minecraft.entity.passive.CowEntity;
import net.minecraft.entity.passive.PigEntity;
import net.minecraft.entity.passive.RabbitEntity;
import net.minecraft.entity.passive.SheepEntity;
import net.minecraft.entity.passive.TameableEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.LiteralText;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.EnumSet;
import java.util.List;
import java.util.function.Predicate;

/**
 * Охота: найти цель -> убить -> подобрать дроп -> вернуться к хозяину.
 * Внимание: цели у мобов тикают раз в 2 игровых тика, поэтому все счётчики ниже — «тики цели».
 */
public class PetTaskGoal extends Goal {
    private final TameableEntity pet;
    private int attackCooldown;
    private int repathCooldown;

    public PetTaskGoal(TameableEntity pet) {
        this.pet = pet;
        this.setControls(EnumSet.of(Goal.Control.MOVE, Goal.Control.LOOK));
    }

    private PetFreedom self() {
        return (PetFreedom) pet;
    }

    @Override
    public boolean canStart() {
        if (!pet.isTamed() || pet.isSitting()) return false;
        if (self().freepets$getTask() != null) return true;

        // Режим wild: иногда сам нападает на ближайшую дичь
        if (self().freepets$getMode() == PetMode.WILD && pet.getRandom().nextInt(200) == 0) {
            LivingEntity prey = findNearest(null);
            if (prey != null) {
                PetTask task = new PetTask(prey.getType(), 1, true);
                task.current = prey;
                self().freepets$setTask(task);
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean shouldContinue() {
        return pet.isTamed() && !pet.isSitting() && self().freepets$getTask() != null;
    }

    @Override
    public void stop() {
        pet.getNavigation().stop();
    }

    @Override
    public void tick() {
        PetTask task = self().freepets$getTask();
        if (task == null) return;

        task.age++;
        if (attackCooldown > 0) attackCooldown--;
        if (repathCooldown > 0) repathCooldown--;

        if (task.autonomous && task.age > 150) {
            clearTask();
            return;
        }
        if (!task.autonomous && task.phase == PetTask.Phase.HUNT && task.age > 1800) {
            task.phase = PetTask.Phase.RETURN; // слишком долго — возвращаемся с тем, что есть
        }

        if (task.phase == PetTask.Phase.RETURN) {
            tickReturn(task);
        } else {
            tickHunt(task);
        }
    }

    private void tickHunt(PetTask task) {
        LivingEntity target = task.current;

        if (target != null && (target.isDead() || target.removed)) {
            if (target.isDead()) {
                task.kills++;
                if (!task.autonomous) collectDrops(task, target);
            }
            task.current = null;
            target = null;
            if (task.kills >= task.goal) {
                if (task.autonomous) clearTask();
                else task.phase = PetTask.Phase.RETURN;
                return;
            }
        }

        if (target == null) {
            target = findNearest(task.type);
            task.current = target;
            if (target == null) {
                task.searchTicks++;
                if (task.searchTicks > 100) {
                    notifyOwner("Не нашёл больше целей рядом: " + task.type.getName().getString());
                    if (task.autonomous) clearTask();
                    else task.phase = PetTask.Phase.RETURN;
                } else if (pet.getNavigation().isIdle()) {
                    Vec3d p = TargetFinder.findTarget(pet, 16, 7); // побродить в поисках
                    if (p != null) pet.getNavigation().startMovingTo(p.x, p.y, p.z, 1.1);
                }
                return;
            }
            task.searchTicks = 0;
        }

        pet.getLookControl().lookAt(target, 30.0F, 30.0F);
        if (repathCooldown <= 0) {
            repathCooldown = 5;
            pet.getNavigation().startMovingTo(target, 1.3);
        }

        double reach = pet.getWidth() * 2.0F * pet.getWidth() * 2.0F + target.getWidth();
        if (attackCooldown <= 0 && pet.squaredDistanceTo(target) <= reach) {
            attackCooldown = 10; // ~20 игровых тиков
            pet.swingHand(Hand.MAIN_HAND);
            pet.tryAttack(target);
        }
    }

    private void tickReturn(PetTask task) {
        LivingEntity ownerEntity = pet.getOwner();
        if (!(ownerEntity instanceof ServerPlayerEntity) || ownerEntity.world != pet.world) {
            pet.getNavigation().stop();
            return;
        }
        ServerPlayerEntity owner = (ServerPlayerEntity) ownerEntity;

        task.returnTicks++;
        pet.getLookControl().lookAt(owner, 30.0F, 30.0F);
        if (repathCooldown <= 0) {
            repathCooldown = 10;
            pet.getNavigation().startMovingTo(owner, 1.3);
        }
        if (pet.squaredDistanceTo(owner) <= 6.0) {
            PetUtil.deliver(pet, task, owner);
            clearTask();
        } else if (task.returnTicks > 100) {
            PetUtil.teleportNear(pet, owner); // застрял по дороге — телепортируем
        }
    }

    /** Подбирает предметы, выпавшие из убитого моба. */
    private void collectDrops(PetTask task, LivingEntity victim) {
        Box box = victim.getBoundingBox().expand(3.0, 2.0, 3.0);
        for (ItemEntity item : pet.world.getEntitiesByClass(ItemEntity.class, box, i -> i.isAlive())) {
            task.haul.add(item.getStack().copy());
            item.remove();
        }
    }

    private LivingEntity findNearest(final EntityType<?> type) {
        Box box = pet.getBoundingBox().expand(24.0, 10.0, 24.0);
        Predicate<Entity> filter = e -> {
            if (!(e instanceof LivingEntity) || !e.isAlive()) return false;
            if (e.hasCustomName()) return false;                                        // именных не трогаем
            if (e instanceof TameableEntity && ((TameableEntity) e).isTamed()) return false; // питомцев тоже
            return type != null ? e.getType() == type : isFreeGame(e);
        };

        Entity best = null;
        double bestDist = Double.MAX_VALUE;
        List<Entity> found = pet.world.getOtherEntities(pet, box, filter);
        for (Entity e : found) {
            double d = pet.squaredDistanceTo(e);
            if (d < bestDist) {
                best = e;
                bestDist = d;
            }
        }
        return (LivingEntity) best;
    }

    /** Что питомец в режиме wild считает дичью. */
    private static boolean isFreeGame(Entity e) {
        if (e instanceof ZombifiedPiglinEntity || e instanceof WitherSkeletonEntity) return false;
        return e instanceof CowEntity || e instanceof PigEntity || e instanceof SheepEntity
                || e instanceof ChickenEntity || e instanceof RabbitEntity
                || e instanceof ZombieEntity || e instanceof AbstractSkeletonEntity
                || e instanceof SpiderEntity;
    }

    private void notifyOwner(String message) {
        LivingEntity owner = pet.getOwner();
        if (owner instanceof ServerPlayerEntity) {
            ((ServerPlayerEntity) owner).sendMessage(
                    new LiteralText("").append(pet.getDisplayName()).append(new LiteralText(": " + message)), false);
        }
    }

    private void clearTask() {
        self().freepets$setTask(null);
        pet.getNavigation().stop();
    }
}
