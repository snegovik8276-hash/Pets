package com.example.freepets.mixin;

import com.example.freepets.PetFreedom;
import com.example.freepets.PetMode;
import net.minecraft.entity.ai.goal.FollowOwnerGoal;
import net.minecraft.entity.passive.TameableEntity;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Выключает ванильное «ходить за хозяином» (и телепорт к нему), если питомец не в режиме follow. */
@Mixin(FollowOwnerGoal.class)
public class FollowOwnerGoalMixin {
    @Shadow @Final private TameableEntity tameable;

    @Inject(method = "canStart", at = @At("HEAD"), cancellable = true)
    private void freepets$noStart(CallbackInfoReturnable<Boolean> cir) {
        if (((PetFreedom) tameable).freepets$getMode() != PetMode.FOLLOW) {
            cir.setReturnValue(false);
        }
    }

    @Inject(method = "shouldContinue", at = @At("HEAD"), cancellable = true)
    private void freepets$noContinue(CallbackInfoReturnable<Boolean> cir) {
        if (((PetFreedom) tameable).freepets$getMode() != PetMode.FOLLOW) {
            cir.setReturnValue(false);
        }
    }
}
