package com.example.freepets.mixin;

import com.example.freepets.PetFreedom;
import com.example.freepets.PetTask;
import com.example.freepets.goal.FreeRoamGoal;
import com.example.freepets.goal.PetTaskGoal;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.entity.passive.TameableEntity;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(TameableEntity.class)
public abstract class TameableEntityMixin extends AnimalEntity implements PetFreedom {
    @Unique private int freepets$mode; // 0 = ROAM по умолчанию
    @Unique private PetTask freepets$task;

    protected TameableEntityMixin(EntityType<? extends AnimalEntity> entityType, World world) {
        super(entityType, world);
    }

    @Inject(method = "<init>", at = @At("TAIL"))
    private void freepets$addGoals(EntityType<? extends TameableEntity> type, World world, CallbackInfo ci) {
        TameableEntity self = (TameableEntity) (Object) this;
        this.goalSelector.add(1, new PetTaskGoal(self));
        this.goalSelector.add(9, new FreeRoamGoal(self));
    }

    @Inject(method = "writeCustomDataToTag", at = @At("TAIL"))
    private void freepets$write(CompoundTag tag, CallbackInfo ci) {
        tag.putInt("FreePetsMode", freepets$mode);
    }

    @Inject(method = "readCustomDataFromTag", at = @At("TAIL"))
    private void freepets$read(CompoundTag tag, CallbackInfo ci) {
        freepets$mode = tag.getInt("FreePetsMode");
    }

    @Override public int freepets$getMode() { return freepets$mode; }
    @Override public void freepets$setMode(int mode) { freepets$mode = mode; }
    @Override public PetTask freepets$getTask() { return freepets$task; }
    @Override public void freepets$setTask(PetTask task) { freepets$task = task; }
}
